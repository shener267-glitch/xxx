# Project HEMO Status

## Current phase
Prototype 0.1 — initial interactive build.

## Implemented
- Three.js 3D lab, floor, walls, lights and grid
- Procedural full-body mannequin
- Touch-compatible orbit camera
- Particle emission, gravity and configurable initial speed
- Approximate floor/wall/torso/head collisions
- Persistent stain decals until experiment reset
- Start, pause, burst, reset, camera reset and clear stains
- Rate, speed, gravity, time-scale controls
- Particle/stain counters, elapsed time and FPS
- Responsive control panel

## Known limitations
- Visual approximation, not validated fluid dynamics or medical simulation
- Mannequin collision zones are approximate; individual limb collision is not implemented
- Three.js is loaded from CDN; internet required
- Not yet verified on a physical iPhone; test via HTTPS/Replit preview

## Next steps
1. Run in browser and fix runtime errors.
2. Improve collision and stains attached to moving human surfaces.
3. Add save/load if desired.
4. Profile performance on a real phone.
